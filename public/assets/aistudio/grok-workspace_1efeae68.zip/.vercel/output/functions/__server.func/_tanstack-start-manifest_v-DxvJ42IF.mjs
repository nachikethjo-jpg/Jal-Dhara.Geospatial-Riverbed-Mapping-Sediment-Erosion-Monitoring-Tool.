//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DxvJ42IF.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DOqAmEZX.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DOqAmEZX.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BnQq2StB.js"]
	}
} });
//#endregion
export { tsrStartManifest };
