import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Pause, c as ChevronDown, i as Play, o as Mountain, r as Satellite, s as Layers, t as Waves } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B8foISnh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-paper/35 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] transition-[color,background-color,opacity,transform,box-shadow] duration-150 ease-out", {
	variants: {
		variant: {
			default: "bg-paper text-ink hover:bg-paper/90",
			ghost: "bg-transparent text-fg hover:bg-surface-2",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			subtle: "bg-surface-2 text-fg hover:bg-surface-2/80"
		},
		size: {
			default: "h-11 px-4 text-sm",
			sm: "h-9 px-3 text-xs",
			icon: "size-11",
			chip: "h-9 px-3 text-xs"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var EARTH_KM = 6371;
function toRad(deg) {
	return deg * Math.PI / 180;
}
function toDeg(rad) {
	return rad * 180 / Math.PI;
}
function destination(from, bearingDeg, distKm) {
	const δ = distKm / EARTH_KM;
	const θ = toRad(bearingDeg);
	const φ1 = toRad(from[1]);
	const λ1 = toRad(from[0]);
	const φ2 = Math.asin(Math.sin(φ1) * Math.cos(δ) + Math.cos(φ1) * Math.sin(δ) * Math.cos(θ));
	return [toDeg(λ1 + Math.atan2(Math.sin(θ) * Math.sin(δ) * Math.cos(φ1), Math.cos(δ) - Math.sin(φ1) * Math.sin(φ2))), toDeg(φ2)];
}
function bearingBetween(a, b) {
	const φ1 = toRad(a[1]);
	const φ2 = toRad(b[1]);
	const Δλ = toRad(b[0] - a[0]);
	const y = Math.sin(Δλ) * Math.cos(φ2);
	const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
	return (toDeg(Math.atan2(y, x)) + 360) % 360;
}
function haversineKm(a, b) {
	const Δφ = toRad(b[1] - a[1]);
	const Δλ = toRad(b[0] - a[0]);
	const φ1 = toRad(a[1]);
	const φ2 = toRad(b[1]);
	const h = Math.sin(Δφ / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
	return 2 * EARTH_KM * Math.asin(Math.min(1, Math.sqrt(h)));
}
function lengthKm(line) {
	let sum = 0;
	for (let i = 1; i < line.length; i++) sum += haversineKm(line[i - 1], line[i]);
	return sum;
}
function resample(line, n) {
	if (line.length === 0) return [];
	if (n <= 1) return [line[0]];
	const seg = [0];
	for (let i = 1; i < line.length; i++) seg.push(seg[i - 1] + haversineKm(line[i - 1], line[i]));
	const total = seg[seg.length - 1] || 1;
	const out = [];
	for (let i = 0; i < n; i++) {
		const d = total * i / (n - 1);
		let k = 1;
		while (k < seg.length && seg[k] < d) k++;
		const d0 = seg[k - 1];
		const d1 = seg[k] ?? d0;
		const t = d1 === d0 ? 0 : (d - d0) / (d1 - d0);
		const a = line[k - 1];
		const b = line[Math.min(k, line.length - 1)];
		out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
	}
	return out;
}
function lerpLine(a, b, t) {
	const n = Math.max(a.length, b.length, 2);
	const ar = resample(a, n);
	const br = resample(b, n);
	return ar.map((p, i) => [p[0] + (br[i][0] - p[0]) * t, p[1] + (br[i][1] - p[1]) * t]);
}
function smoothstep(t) {
	const x = Math.min(1, Math.max(0, t));
	return x * x * (3 - 2 * x);
}
function hash01(i, salt) {
	const x = Math.sin(i * 127.1 + salt * 311.7) * 43758.5453;
	return x - Math.floor(x);
}
function meanderize(path, ampKm, waveKm, phase = 0, harmonics = true) {
	const dense = resample(path, Math.max(48, Math.round(lengthKm(path) / Math.max(.6, waveKm / 10))));
	let dist = 0;
	return dense.map((pt, i) => {
		if (i > 0) dist += haversineKm(dense[i - 1], pt);
		const prev = dense[Math.max(0, i - 1)];
		const next = dense[Math.min(dense.length - 1, i + 1)];
		const bear = bearingBetween(prev, next);
		const wobble = harmonics ? .28 * Math.sin(dist / (waveKm * .43) * Math.PI * 2 + phase * 1.7) : 0;
		const noise = (hash01(i, phase * 10) - .5) * .18;
		const offset = ampKm * (Math.sin(dist / waveKm * Math.PI * 2 + phase) + wobble + noise);
		return destination(pt, bear + 90, offset);
	});
}
function bufferLine(coords, widthKm) {
	if (coords.length < 2) return [];
	const left = [];
	const right = [];
	const half = widthKm / 2;
	for (let i = 0; i < coords.length; i++) {
		const prev = coords[Math.max(0, i - 1)];
		const next = coords[Math.min(coords.length - 1, i + 1)];
		const bear = bearingBetween(prev, next);
		left.push(destination(coords[i], bear - 90, half));
		right.push(destination(coords[i], bear + 90, half));
	}
	const ring = [...left, ...right.reverse()];
	ring.push(ring[0]);
	return ring;
}
function shiftLine(line, bearingDeg, distKm) {
	return line.map((p) => destination(p, bearingDeg, distKm));
}
var ghaggarLost = [
	[77.22, 30.48],
	[76.9, 30.32],
	[76.5, 30.18],
	[76.05, 29.95],
	[75.5, 29.7],
	[75.03, 29.53],
	[74.55, 29.52],
	[74.32, 29.58],
	[73.9, 29.32],
	[73.4, 29.18],
	[72.85, 29.08],
	[72.2, 28.92],
	[71.33, 28.77],
	[70.7, 28.35],
	[70.05, 27.65]
];
var yamunaBorn = [
	[77.22, 30.48],
	[77.45, 30.1],
	[77.2, 29.65],
	[77.22, 28.9],
	[77.45, 28.15],
	[78.02, 27.18],
	[78.6, 26.45],
	[79.45, 25.75],
	[80.35, 25.45],
	[81.85, 25.43]
];
var sutlejScar = [
	[77.05, 31.15],
	[76.55, 31],
	[75.85, 30.9],
	[75.15, 31.13],
	[74.4, 30.95],
	[73.7, 30.55],
	[72.9, 30.15]
];
var kosiHead = [
	[87.17, 26.87],
	[87.08, 26.72],
	[86.96, 26.54]
];
var kosiOld = [
	...kosiHead,
	[86.93, 26.38],
	[86.9, 26.2],
	[86.86, 26.02],
	[86.83, 25.84],
	[86.8, 25.66],
	[86.78, 25.5],
	[86.92, 25.43],
	[87.22, 25.4]
];
var kosiNew = [
	...kosiHead,
	[87.12, 26.46],
	[87.28, 26.32],
	[87.4, 26.14],
	[87.48, 25.94],
	[87.5, 25.74],
	[87.46, 25.56],
	[87.36, 25.44],
	[87.22, 25.39]
];
var teestaHead = [
	[88.5, 27.2],
	[88.48, 26.9],
	[88.58, 26.7],
	[88.73, 26.52]
];
var teestaOld = [
	...teestaHead,
	[88.9, 26.15],
	[89.1, 25.85],
	[89.25, 25.55],
	[89.35, 25.15],
	[89.4, 24.85],
	[89.55, 24.45],
	[89.75, 24.05]
];
var teestaNew = [
	...teestaHead,
	[88.95, 26.3],
	[89.25, 26.05],
	[89.45, 25.8],
	[89.67, 25.52]
];
var gangaHead = [
	[87.25, 25.25],
	[87.6, 25.02],
	[87.92, 24.8]
];
var hooghly = meanderize([
	...gangaHead,
	[88.08, 24.45],
	[88.16, 24.1],
	[88.25, 23.7],
	[88.34, 23.4],
	[88.36, 23.05],
	[88.22, 22.55],
	[88.08, 22.1],
	[88.02, 21.7]
], 2.2, 28, .4);
var padma = [
	...gangaHead,
	[88.25, 24.65],
	[88.6, 24.35],
	[89, 24.1],
	[89.45, 23.8],
	[89.8, 23.55],
	[90.25, 23.25],
	[90.55, 22.95]
];
var mahanadiHead = [
	[83.95, 21.52],
	[84.35, 21.15],
	[84.85, 20.82],
	[85.4, 20.55],
	[85.88, 20.46]
];
var mahanadiOld = [
	...mahanadiHead,
	[86.15, 20.42],
	[86.4, 20.35],
	[86.58, 20.3],
	[86.72, 20.26]
];
var deviBorn = meanderize([
	...mahanadiHead,
	[85.98, 20.28],
	[86.15, 20.08],
	[86.28, 19.9],
	[86.38, 19.78]
], 1.4, 18, .8);
var kaveriHead = [
	[78.35, 11.4],
	[78.65, 11.05],
	[78.82, 10.83]
];
var kaveriOld = [
	...kaveriHead,
	[79.1, 10.82],
	[79.35, 10.78],
	[79.6, 10.88],
	[79.85, 11.12]
];
var kollidam = [
	...kaveriHead,
	[79.05, 10.95],
	[79.3, 11.1],
	[79.55, 11.25],
	[79.82, 11.36]
];
var RIVERS = [
	{
		id: "ghaggar",
		name: "Ghaggar–Hakra",
		localName: "Saraswati",
		region: "Haryana, Rajasthan, Cholistan",
		kind: "avulsion",
		eventYear: -1900,
		era: [-4e3, 2026],
		eventLabel: "Perennial flow lost, c. 1900 BCE",
		lede: "The river that left its bed in the desert and never came back.",
		essay: "The Ghaggar–Hakra is the dry scar of a river that once ran from the Siwalik foothills across Haryana and Rajasthan into Cholistan. Its eastern feed was captured by the Yamuna, which now joins the Ganga at Prayagraj. Its western feed was captured by the Sutlej, which now joins the Indus. By about 1900 BCE the long bed no longer reached the sea. What remains is a seasonal nala, a line of Harappan towns, and a paleochannel you can still read from the air. The bright thread on this map is the Yamuna — the channel that was made when this one was lost.",
		view: {
			center: [74.6, 29.2],
			zoom: 6.15,
			pitch: 22,
			bearing: 8
		},
		lost: ghaggarLost,
		born: yamunaBorn,
		scars: [
			sutlejScar,
			shiftLine(ghaggarLost, 20, 28),
			shiftLine(ghaggarLost, 200, 22)
		],
		lostLoops: [],
		widthKm: 3.2
	},
	{
		id: "kosi",
		name: "Kosi",
		localName: "Sorrow of Bihar",
		region: "Nepal / Bihar",
		kind: "avulsion",
		eventYear: 2008,
		era: [1890, 2026],
		eventLabel: "Kusaha breach, 18 August 2008",
		lede: "In one monsoon the river jumped a hundred kilometres across its own fan.",
		essay: "The Kosi leaves the Himalaya and builds a megafan 150 km wide. It has occupied many beds across that fan. Embankments tried to pin it to one. On 18 August 2008 the eastern bund failed at Kusaha. The river left a channel it had used for more than a century and tore southeast through settled Bihar — a new bed, uninvited. About three million people were displaced. The faint threads are older courses. 2008 was not an exception. It was the latest rewrite.",
		view: {
			center: [87.15, 25.95],
			zoom: 8.15,
			pitch: 28,
			bearing: 8
		},
		lost: kosiOld,
		born: kosiNew,
		scars: [
			shiftLine(kosiOld, 90, 18),
			shiftLine(kosiOld, 80, 36),
			shiftLine(kosiOld, 270, 14)
		],
		lostLoops: [],
		widthKm: 1.6,
		displaced: "3 million"
	},
	{
		id: "teesta",
		name: "Teesta",
		localName: "Tista",
		region: "Sikkim, North Bengal, Bangladesh",
		kind: "avulsion",
		eventYear: 1787,
		era: [1650, 2026],
		eventLabel: "Flood avulsion, 1787",
		lede: "A flood took the Teesta away from the Ganga and gave it to the Brahmaputra.",
		essay: "Until 1787 the Teesta came off the Sikkim hills, passed Jalpaiguri, and ran south through the Karatoya and Atrai into the Ganga. That monsoon it broke east. The new bed met the Brahmaputra near Chilmari. The old course shrunk into the Karatoya, a river that still carries the name of a channel the Teesta abandoned. One flood redrew the drainage of North Bengal.",
		view: {
			center: [89.15, 25.85],
			zoom: 7.55,
			pitch: 30,
			bearing: -8
		},
		lost: teestaOld,
		born: teestaNew,
		scars: [shiftLine(teestaOld, 80, 12)],
		lostLoops: [],
		widthKm: .9
	},
	{
		id: "ganga",
		name: "Ganga",
		localName: "Bhagirathi–Hooghly and Padma",
		region: "West Bengal / Bangladesh",
		kind: "avulsion",
		eventYear: 1700,
		era: [1500, 2026],
		eventLabel: "Mainstem shift to the Padma",
		lede: "The river that built Kolkata kept most of its water for the Padma.",
		essay: "For centuries the main Ganga spilled down the Bhagirathi–Hooghly, past Murshidabad and what became Kolkata, to the Bay of Bengal. The discharge drifted east. The Padma, through Rajshahi and Goalundo, became the living mainstem; the Hooghly was left a diminished distributary. The Farakka Barrage, finished in 1975, was built to push water back into the old bed so the port would not silt shut. The lost channel is still a river. It is no longer the river.",
		view: {
			center: [88.7, 23.7],
			zoom: 6.7,
			pitch: 24,
			bearing: 6
		},
		lost: hooghly,
		born: padma,
		scars: [shiftLine(hooghly, 70, 14)],
		lostLoops: [],
		widthKm: 2.4
	},
	{
		id: "mahanadi",
		name: "Mahanadi",
		localName: "Devi mouth",
		region: "Chhattisgarh and Odisha",
		kind: "avulsion",
		eventYear: 1850,
		era: [1750, 2026],
		eventLabel: "Flood share shifts into the Devi",
		lede: "A river born in Chhattisgarh argues with its own delta.",
		essay: "The Mahanadi rises in the hills of Chhattisgarh, crosses the Hirakud gorge, and reaches the sea in a fan of mouths below Cuttack. The old main thread runs east to Paradeep. Over the last two centuries a growing share of the flood has taken the Devi south to Astaranga, leaving the Paradeep branch with less of the water that cut it. Naraj and the anicuts try to ration what the river already decided. The lost bed and the new one leave the same barrage and disagree about the Bay.",
		view: {
			center: [85.7, 20.35],
			zoom: 8.35,
			pitch: 36,
			bearing: -12
		},
		lost: mahanadiOld,
		born: deviBorn,
		scars: [],
		lostLoops: [],
		widthKm: .85
	},
	{
		id: "kaveri",
		name: "Kaveri",
		localName: "Kollidam",
		region: "Tamil Nadu",
		kind: "engineered",
		eventYear: 1830,
		era: [1780, 2026],
		eventLabel: "Coleroon capture, anicut rebuilt",
		lede: "The flood wanted the Kollidam. The anicut kept the Kaveri.",
		essay: "Below the Grand Anicut the Kaveri splits. The northern branch, the Kollidam or Coleroon, is the steeper flood path. By the early 19th century it was taking the river, and the southern Kaveri — the bed that feeds the delta — was silting. Engineers rebuilt the anicut to push water back into the old course. The new bed is the one the river prefers. The lost bed is the one the delta cannot afford to lose. Both still reach the sea, a few kilometres apart, carrying an argument that started under the Cholas.",
		view: {
			center: [79.25, 11.05],
			zoom: 8.7,
			pitch: 34,
			bearing: 10
		},
		lost: kaveriOld,
		born: kollidam,
		scars: [],
		lostLoops: [],
		widthKm: .55
	}
];
var RIVER_BY_ID = Object.fromEntries(RIVERS.map((r) => [r.id, r]));
var KIND_LABEL = {
	cutoff: "Meander cutoff",
	avulsion: "Avulsion",
	braid: "Braid migration",
	engineered: "Engineered channel"
};
function lineFeat(coords, kind, name) {
	return {
		type: "Feature",
		properties: {
			kind,
			name
		},
		geometry: {
			type: "LineString",
			coordinates: coords
		}
	};
}
function polyFeat(ring, kind, name) {
	return {
		type: "Feature",
		properties: {
			kind,
			name
		},
		geometry: {
			type: "Polygon",
			coordinates: [ring]
		}
	};
}
function morphT(river, year) {
	const [a, b] = river.era;
	const span = Math.max(12, (b - a) * .12);
	const t0 = river.eventYear - span * .35;
	const t1 = river.eventYear + span * .65;
	return smoothstep((year - t0) / (t1 - t0));
}
function buildScene(river, year) {
	const t = morphT(river, year);
	const water = lerpLine(river.lost, river.born, t);
	const features = [];
	for (const scar of river.scars) features.push(lineFeat(scar, "scar", river.name));
	features.push(polyFeat(bufferLine(river.lost, river.widthKm * 1.15), "lost-fill", river.name));
	features.push(polyFeat(bufferLine(river.born, river.widthKm * .95), "born-fill", river.name));
	for (const loop of river.lostLoops) features.push(polyFeat(loop, "loop", `${river.name} oxbow`));
	features.push(lineFeat(river.lost, "lost", `${river.name} lost bed`));
	features.push(lineFeat(river.born, "born", `${river.name} new bed`));
	features.push(lineFeat(water, "water", `${river.name} water`));
	return {
		type: "FeatureCollection",
		features
	};
}
function riverStats(river) {
	const lostKm = lengthKm(river.lost);
	const bornKm = lengthKm(river.born);
	return {
		lostKm,
		bornKm,
		deltaKm: bornKm - lostKm,
		loops: river.lostLoops.length,
		t: morphT(river, river.eventYear)
	};
}
function formatKm(n) {
	if (Math.abs(n) >= 100) return `${Math.round(n)} km`;
	if (Math.abs(n) >= 10) return `${n.toFixed(0)} km`;
	return `${n.toFixed(1)} km`;
}
function formatYear(year) {
	const y = Math.round(year);
	if (y < 0) return `${Math.abs(y)} BCE`;
	return String(y);
}
var MAP_PAINT = {
	lost: "#c46a4a",
	lostFill: "rgba(196, 106, 74, 0.30)",
	loopFill: "rgba(196, 106, 74, 0.22)",
	born: "#4aa89a",
	bornFill: "rgba(74, 168, 154, 0.28)",
	water: "#e7f6f1",
	waterGlow: "#3d9b8f",
	scar: "rgba(196, 106, 74, 0.45)",
	ink: "#0b100e",
	paper: "#e8e2d6"
};
var esriImagery = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
var esriTopo = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}";
var cartoInk = "https://basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}@2x.png";
function rasterStyle(id, tiles, attribution, bg) {
	return {
		version: 8,
		name: id,
		sources: { basemap: {
			type: "raster",
			tiles,
			tileSize: 256,
			attribution,
			maxzoom: 19
		} },
		layers: [{
			id: "background",
			type: "background",
			paint: { "background-color": bg }
		}, {
			id: "basemap",
			type: "raster",
			source: "basemap"
		}]
	};
}
function styleFor(id) {
	if (id === "satellite") return rasterStyle("satellite", [esriImagery], "Imagery © Esri", MAP_PAINT.ink);
	if (id === "terrain") return rasterStyle("terrain", [esriTopo], "Topo © Esri", "#d6d2c4");
	return rasterStyle("ink", [cartoInk], "© CARTO © OSM", MAP_PAINT.ink);
}
var BASEMAPS = [
	{
		id: "satellite",
		label: "Satellite"
	},
	{
		id: "terrain",
		label: "Terrain"
	},
	{
		id: "ink",
		label: "Ink"
	}
];
var first = RIVERS[0];
var useAtlas = create((set, get) => ({
	riverId: first.id,
	year: first.eventYear,
	playing: false,
	layers: {
		lost: true,
		born: true,
		water: true
	},
	basemap: "satellite",
	storyOpen: false,
	setRiver: (id) => {
		const river = RIVERS.find((r) => r.id === id) ?? first;
		set({
			riverId: river.id,
			year: river.eventYear,
			playing: false
		});
	},
	setYear: (year) => set({ year }),
	setPlaying: (playing) => set({ playing }),
	toggleLayer: (key) => {
		const layers = get().layers;
		set({ layers: {
			...layers,
			[key]: !layers[key]
		} });
	},
	setBasemap: (id) => set({ basemap: id }),
	setStoryOpen: (open) => set({ storyOpen: open })
}));
function makeHatch() {
	const c = document.createElement("canvas");
	c.width = 16;
	c.height = 16;
	const g = c.getContext("2d");
	if (!g) return new ImageData(16, 16);
	g.clearRect(0, 0, 16, 16);
	g.strokeStyle = "rgba(196, 106, 74, 0.85)";
	g.lineWidth = 2;
	g.beginPath();
	g.moveTo(-2, 8);
	g.lineTo(8, -2);
	g.moveTo(0, 18);
	g.lineTo(18, 0);
	g.stroke();
	return g.getImageData(0, 0, 16, 16);
}
function addChannelLayers(map) {
	if (map.getSource("channels")) return;
	map.addSource("channels", {
		type: "geojson",
		data: {
			type: "FeatureCollection",
			features: []
		}
	});
	map.addLayer({
		id: "scar-line",
		type: "line",
		source: "channels",
		filter: [
			"==",
			["get", "kind"],
			"scar"
		],
		paint: {
			"line-color": MAP_PAINT.scar,
			"line-width": [
				"interpolate",
				["linear"],
				["zoom"],
				5,
				1.2,
				10,
				2.4,
				14,
				4
			],
			"line-dasharray": [1.2, 1.4],
			"line-opacity": .55
		}
	});
	map.addLayer({
		id: "lost-fill",
		type: "fill",
		source: "channels",
		filter: [
			"==",
			["get", "kind"],
			"lost-fill"
		],
		paint: {
			"fill-color": MAP_PAINT.lostFill,
			"fill-opacity": .85
		}
	});
	if (!map.hasImage("lost-hatch")) map.addImage("lost-hatch", makeHatch(), { pixelRatio: 2 });
	map.addLayer({
		id: "lost-hatch",
		type: "fill",
		source: "channels",
		filter: [
			"==",
			["get", "kind"],
			"lost-fill"
		],
		paint: {
			"fill-pattern": "lost-hatch",
			"fill-opacity": .45
		}
	});
	map.addLayer({
		id: "loop-fill",
		type: "fill",
		source: "channels",
		filter: [
			"==",
			["get", "kind"],
			"loop"
		],
		paint: {
			"fill-color": MAP_PAINT.loopFill,
			"fill-opacity": .9
		}
	});
	map.addLayer({
		id: "born-fill",
		type: "fill",
		source: "channels",
		filter: [
			"==",
			["get", "kind"],
			"born-fill"
		],
		paint: {
			"fill-color": MAP_PAINT.bornFill,
			"fill-opacity": .8
		}
	});
	map.addLayer({
		id: "lost-line",
		type: "line",
		source: "channels",
		filter: [
			"==",
			["get", "kind"],
			"lost"
		],
		layout: {
			"line-cap": "round",
			"line-join": "round"
		},
		paint: {
			"line-color": MAP_PAINT.lost,
			"line-width": [
				"interpolate",
				["linear"],
				["zoom"],
				5,
				1.6,
				8,
				2.8,
				12,
				5,
				15,
				8
			],
			"line-dasharray": [1.6, 1.1],
			"line-opacity": .95
		}
	});
	map.addLayer({
		id: "born-line",
		type: "line",
		source: "channels",
		filter: [
			"==",
			["get", "kind"],
			"born"
		],
		layout: {
			"line-cap": "round",
			"line-join": "round"
		},
		paint: {
			"line-color": MAP_PAINT.born,
			"line-width": [
				"interpolate",
				["linear"],
				["zoom"],
				5,
				1.8,
				8,
				3.2,
				12,
				5.5,
				15,
				9
			],
			"line-opacity": .95
		}
	});
	map.addLayer({
		id: "water-glow",
		type: "line",
		source: "channels",
		filter: [
			"==",
			["get", "kind"],
			"water"
		],
		layout: {
			"line-cap": "round",
			"line-join": "round"
		},
		paint: {
			"line-color": MAP_PAINT.waterGlow,
			"line-width": [
				"interpolate",
				["linear"],
				["zoom"],
				5,
				4,
				8,
				8,
				12,
				14,
				15,
				22
			],
			"line-blur": [
				"interpolate",
				["linear"],
				["zoom"],
				5,
				2,
				12,
				6
			],
			"line-opacity": .55
		}
	});
	map.addLayer({
		id: "water-core",
		type: "line",
		source: "channels",
		filter: [
			"==",
			["get", "kind"],
			"water"
		],
		layout: {
			"line-cap": "round",
			"line-join": "round"
		},
		paint: {
			"line-color": MAP_PAINT.water,
			"line-width": [
				"interpolate",
				["linear"],
				["zoom"],
				5,
				1.4,
				8,
				2.4,
				12,
				4,
				15,
				6.5
			],
			"line-opacity": .95
		}
	});
}
function setLayerVis(map, ids, visible) {
	for (const id of ids) if (map.getLayer(id)) map.setLayoutProperty(id, "visibility", visible ? "visible" : "none");
}
function RiverMap() {
	const hostRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const readyRef = (0, import_react.useRef)(false);
	const riverId = useAtlas((s) => s.riverId);
	const year = useAtlas((s) => s.year);
	const layers = useAtlas((s) => s.layers);
	const basemap = useAtlas((s) => s.basemap);
	const stateRef = (0, import_react.useRef)({
		riverId,
		year,
		layers,
		basemap
	});
	stateRef.current = {
		riverId,
		year,
		layers,
		basemap
	};
	const flownRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!hostRef.current) return;
		let cancelled = false;
		let map;
		let ro;
		const apply = (m) => {
			if (!m.isStyleLoaded()) return;
			addChannelLayers(m);
			const st = stateRef.current;
			const river = RIVER_BY_ID[st.riverId];
			m.getSource("channels")?.setData(buildScene(river, st.year));
			setLayerVis(m, [
				"lost-fill",
				"lost-hatch",
				"lost-line",
				"loop-fill",
				"scar-line"
			], st.layers.lost);
			setLayerVis(m, ["born-fill", "born-line"], st.layers.born);
			setLayerVis(m, ["water-glow", "water-core"], st.layers.water);
		};
		(async () => {
			const maplibregl = await import("../_libs/maplibre-gl.mjs").then((n) => n.t);
			const host = hostRef.current;
			if (cancelled || !host) return;
			maplibregl.setWorkerUrl("/maplibre/maplibre-gl-worker.mjs");
			const river = RIVER_BY_ID[stateRef.current.riverId];
			map = new maplibregl.Map({
				container: host,
				style: styleFor(stateRef.current.basemap),
				center: river.view.center,
				zoom: river.view.zoom,
				pitch: river.view.pitch,
				bearing: river.view.bearing,
				attributionControl: false,
				maxPitch: 62,
				fadeDuration: 0
			});
			map.on("load", () => {
				if (!map) return;
				apply(map);
				const current = RIVER_BY_ID[stateRef.current.riverId];
				map.jumpTo({
					center: current.view.center,
					zoom: current.view.zoom,
					pitch: current.view.pitch,
					bearing: current.view.bearing
				});
				flownRef.current = stateRef.current.riverId;
				readyRef.current = true;
			});
			map.on("style.load", () => {
				if (!map) return;
				apply(map);
			});
			mapRef.current = map;
			ro = new ResizeObserver(() => map?.resize());
			ro.observe(host);
		})();
		return () => {
			cancelled = true;
			readyRef.current = false;
			ro?.disconnect();
			map?.remove();
			mapRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const map = mapRef.current;
		if (!map || !readyRef.current) return;
		if (flownRef.current === riverId) return;
		flownRef.current = riverId;
		const river = RIVER_BY_ID[riverId];
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		map.flyTo({
			center: river.view.center,
			zoom: river.view.zoom,
			pitch: river.view.pitch,
			bearing: river.view.bearing,
			duration: reduce ? 0 : 2200,
			essential: true
		});
	}, [riverId]);
	(0, import_react.useEffect)(() => {
		const map = mapRef.current;
		if (!map || !readyRef.current) return;
		if (map.getStyle()?.name === basemap) return;
		map.setStyle(styleFor(basemap));
	}, [basemap]);
	(0, import_react.useEffect)(() => {
		const map = mapRef.current;
		if (!map || !readyRef.current || !map.isStyleLoaded()) return;
		const river = RIVER_BY_ID[riverId];
		map.getSource("channels")?.setData(buildScene(river, year));
		setLayerVis(map, [
			"lost-fill",
			"lost-hatch",
			"lost-line",
			"loop-fill",
			"scar-line"
		], layers.lost);
		setLayerVis(map, ["born-fill", "born-line"], layers.born);
		setLayerVis(map, ["water-glow", "water-core"], layers.water);
	}, [
		riverId,
		year,
		layers
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative h-full min-h-0 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: hostRef,
			className: "bg-bg absolute inset-0"
		})
	});
}
var KIND_TONE = {
	cutoff: "text-lost",
	avulsion: "text-lost",
	braid: "text-born",
	engineered: "text-muted"
};
function usePrefersReducedMotion() {
	const [reduce, setReduce] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		setReduce(mq.matches);
		const onChange = () => setReduce(mq.matches);
		mq.addEventListener("change", onChange);
		return () => mq.removeEventListener("change", onChange);
	}, []);
	return reduce;
}
function BasemapIcon({ id }) {
	if (id === "satellite") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Satellite, {
		className: "size-3.5",
		strokeWidth: 1.75
	});
	if (id === "terrain") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mountain, {
		className: "size-3.5",
		strokeWidth: 1.75
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {
		className: "size-3.5",
		strokeWidth: 1.75
	});
}
function Atlas() {
	const riverId = useAtlas((s) => s.riverId);
	const year = useAtlas((s) => s.year);
	const playing = useAtlas((s) => s.playing);
	const layers = useAtlas((s) => s.layers);
	const basemap = useAtlas((s) => s.basemap);
	const storyOpen = useAtlas((s) => s.storyOpen);
	const setRiver = useAtlas((s) => s.setRiver);
	const setYear = useAtlas((s) => s.setYear);
	const setPlaying = useAtlas((s) => s.setPlaying);
	const toggleLayer = useAtlas((s) => s.toggleLayer);
	const setBasemap = useAtlas((s) => s.setBasemap);
	const setStoryOpen = useAtlas((s) => s.setStoryOpen);
	const reduce = usePrefersReducedMotion();
	const river = RIVER_BY_ID[riverId];
	const stats = (0, import_react.useMemo)(() => riverStats(river), [river]);
	const t = morphT(river, year);
	const [minYear, maxYear] = river.era;
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		let raf = 0;
		let last = performance.now();
		const step = (now) => {
			const dt = now - last;
			last = now;
			const state = useAtlas.getState();
			const [lo, hi] = RIVER_BY_ID[state.riverId].era;
			const speed = (hi - lo) / (reduce ? 14e3 : 9e3);
			const next = state.year + dt / 1e3 * speed;
			if (next >= hi) {
				setYear(hi);
				setPlaying(false);
				return;
			}
			setYear(next);
			raf = requestAnimationFrame(step);
		};
		raf = requestAnimationFrame(step);
		return () => cancelAnimationFrame(raf);
	}, [
		playing,
		reduce,
		setYear,
		setPlaying
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
			const i = RIVERS.findIndex((r) => r.id === riverId);
			if (e.key === "ArrowRight") setRiver(RIVERS[(i + 1) % RIVERS.length].id);
			else if (e.key === "ArrowLeft") setRiver(RIVERS[(i - 1 + RIVERS.length) % RIVERS.length].id);
			else if (e.key === " ") {
				e.preventDefault();
				setPlaying(!playing);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		riverId,
		playing,
		setRiver,
		setPlaying
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-bg text-fg flex h-dvh min-h-0 flex-col overflow-hidden md:flex-row",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "border-border relative z-20 hidden w-80 shrink-0 flex-col overflow-hidden border-r md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RiverList, {
						riverId,
						onSelect: setRiver
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Story, {
						riverId,
						stats,
						t,
						year
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative min-h-0 min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RiverMap, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-3 md:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-auto md:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, { compact: true })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-auto ml-auto flex flex-col items-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-bg/92 shadow-[var(--shadow-border)] flex rounded-xl p-1",
								children: BASEMAPS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setBasemap(b.id),
									className: cn("flex h-11 items-center gap-1.5 rounded-lg px-2.5 text-xs font-medium transition-[background-color,color,opacity] duration-150", basemap === b.id ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"),
									"aria-pressed": basemap === b.id,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BasemapIcon, { id: b.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: b.label
									})]
								}, b.id))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-bg/92 shadow-[var(--shadow-border)] flex flex-col rounded-xl p-1",
								children: [
									{
										key: "lost",
										label: "Lost bed",
										swatch: "bg-lost"
									},
									{
										key: "born",
										label: "New bed",
										swatch: "bg-born"
									},
									{
										key: "water",
										label: "Water",
										swatch: "bg-paper"
									}
								].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => toggleLayer(b.key),
									className: cn("flex h-11 items-center gap-2 rounded-lg px-2.5 text-xs font-medium transition-[background-color,color,opacity] duration-150", layers[b.key] ? "text-fg" : "text-faint"),
									"aria-pressed": layers[b.key],
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", b.swatch, !layers[b.key] && "opacity-30") }), b.label]
								}, b.key))
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-auto mx-auto w-full max-w-3xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeRail, {
							min: minYear,
							max: maxYear,
							year,
							eventYear: river.eventYear,
							eventLabel: river.eventLabel,
							playing,
							t,
							onYear: setYear,
							onTogglePlay: () => setPlaying(!playing)
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-border bg-bg z-20 flex shrink-0 flex-col border-t md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex h-11 items-center justify-between px-4 text-left",
					onClick: () => setStoryOpen(!storyOpen),
					"aria-expanded": storyOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display block truncate text-base font-medium leading-tight",
							children: river.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted text-xs",
							children: river.region
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("text-muted size-4 shrink-0 transition-transform duration-200", storyOpen && "rotate-180") })]
				}), storyOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[48dvh] overflow-y-auto px-4 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RiverList, {
						riverId,
						onSelect: setRiver,
						compact: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Story, {
						riverId,
						stats,
						t,
						year
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto px-3 pb-3",
					children: RIVERS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setRiver(r.id),
						className: cn("h-9 shrink-0 rounded-full px-3 text-xs font-medium", r.id === riverId ? "bg-paper text-ink" : "bg-surface-2 text-muted"),
						children: r.name
					}, r.id))
				})]
			})
		]
	});
}
function Header({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("px-5 pt-5 pb-4", compact && "bg-bg/92 shadow-[var(--shadow-border)] rounded-xl px-3 py-2.5"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-faint font-mono text-xs tracking-widest uppercase",
				children: "Atlas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: cn("font-display mt-1 leading-none tracking-tight", compact ? "text-xl" : "text-3xl"),
				children: "OXBOW"
			}),
			!compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted mt-3 text-sm leading-relaxed text-pretty",
				children: "Lost beds and new channels of India’s rivers."
			}) : null
		]
	});
}
function RiverList({ riverId, onSelect, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: cn(compact ? "py-2" : "px-3 pb-2"),
		"aria-label": "River reaches",
		children: RIVERS.map((r) => {
			const active = r.id === riverId;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onSelect(r.id),
				className: cn("flex w-full items-start gap-3 rounded-lg px-3 py-2.5 text-left transition-[background-color] duration-150", active ? "bg-surface-2" : "hover:bg-surface"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-1.5 size-1.5 shrink-0 rounded-full", active ? "bg-paper" : "bg-faint") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: r.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-faint font-mono text-xs tabular-nums",
							children: formatYear(r.eventYear)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("mt-0.5 block text-xs", KIND_TONE[r.kind]),
						children: KIND_LABEL[r.kind]
					})]
				})]
			}, r.id);
		})
	});
}
function Story({ riverId, stats, t, year }) {
	const river = RIVER_BY_ID[riverId];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-border space-y-4 border-t px-5 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-faint font-mono text-xs tracking-widest uppercase",
				children: river.region
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display mt-1 text-xl leading-tight text-balance",
				children: river.lede
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted text-sm leading-relaxed text-pretty",
				children: river.essay
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Lost bed",
						value: formatKm(stats.lostKm),
						tone: "lost"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "New bed",
						value: formatKm(stats.bornKm),
						tone: "born"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Sinuosity shift",
						value: `${stats.deltaKm > 0 ? "+" : ""}${formatKm(stats.deltaKm)}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "In year",
						value: formatYear(year)
					})
				]
			}),
			river.displaced ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted text-xs leading-relaxed",
				children: ["People displaced: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-fg",
					children: river.displaced
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-faint text-xs leading-relaxed",
				children: [
					"Traces are reconstructed from documented cutoffs and avulsions, simplified to the valley. Water position is interpolated across the event (",
					Math.round(t * 100),
					"% toward the new bed)."
				]
			})
		]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-surface rounded-lg px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-faint text-xs tracking-wide uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: cn("mt-0.5 font-mono text-sm tabular-nums", tone === "lost" && "text-lost", tone === "born" && "text-born"),
			children: value
		})]
	});
}
function TimeRail({ min, max, year, eventYear, eventLabel, playing, t, onYear, onTogglePlay }) {
	const eventPct = (eventYear - min) / (max - min) * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-bg/92 shadow-[var(--shadow-border)] rounded-2xl p-3 md:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-faint font-mono text-xs tracking-widest uppercase",
							children: "Year"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-lg leading-none tabular-nums",
							children: formatYear(year)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted hidden max-w-[18rem] truncate text-right text-xs sm:block",
						children: eventLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "subtle",
						size: "icon",
						className: "size-11 shrink-0",
						onClick: onTogglePlay,
						"aria-label": playing ? "Pause channel change" : "Play channel change",
						children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 ml-0.5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative pt-3 pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "bg-paper/50 absolute top-0 h-2.5 w-px",
					style: { left: `${eventPct}%` },
					title: eventLabel
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "range",
					min,
					max,
					step: 1,
					value: Math.round(year),
					onChange: (e) => onYear(Number(e.target.value)),
					className: "time-range",
					"aria-label": "Year"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-faint mt-1 flex justify-between font-mono text-xs tabular-nums",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatYear(min) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waves, {
							className: "size-3",
							strokeWidth: 1.75
						}), t < .15 ? "on the old bed" : t > .85 ? "on the new bed" : "rewriting the bed"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatYear(max) })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendSwatch, {
						className: "border-lost bg-lost/30 border-dashed",
						label: "Abandoned"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendSwatch, {
						className: "border-born bg-born/30",
						label: "New channel"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegendSwatch, {
						className: "border-paper bg-paper/40",
						label: "Water"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-faint ml-auto",
						children: "Imagery © Esri · CARTO · OSM"
					})
				]
			})
		]
	});
}
function LegendSwatch({ className, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "text-muted flex items-center gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-2 w-5 rounded-sm border", className) }), label]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Atlas, {});
}
//#endregion
export { Home as component };
