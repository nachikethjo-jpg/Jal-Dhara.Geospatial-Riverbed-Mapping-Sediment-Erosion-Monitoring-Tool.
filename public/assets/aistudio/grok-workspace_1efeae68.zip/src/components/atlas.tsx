import { useEffect, useMemo, useState } from "react";
import {
  ChevronDown,
  Layers,
  Pause,
  Play,
  Satellite,
  Mountain,
  Waves,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { RiverMap } from "@/components/river-map";
import { cn } from "@/lib/utils";
import {
  formatKm,
  formatYear,
  KIND_LABEL,
  morphT,
  RIVER_BY_ID,
  RIVERS,
  riverStats,
  type ChannelKind,
  type RiverId,
} from "@/lib/rivers";
import { BASEMAPS, type BasemapId } from "@/lib/map-style";
import { useAtlas, type LayerKey } from "@/store/atlas";

const KIND_TONE: Record<ChannelKind, string> = {
  cutoff: "text-lost",
  avulsion: "text-lost",
  braid: "text-born",
  engineered: "text-muted",
};

function usePrefersReducedMotion() {
  const [reduce, setReduce] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduce(mq.matches);
    const onChange = () => setReduce(mq.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return reduce;
}

function BasemapIcon({ id }: { id: BasemapId }) {
  if (id === "satellite") return <Satellite className="size-3.5" strokeWidth={1.75} />;
  if (id === "terrain") return <Mountain className="size-3.5" strokeWidth={1.75} />;
  return <Layers className="size-3.5" strokeWidth={1.75} />;
}

export function Atlas() {
  const riverId = useAtlas((s) => s.riverId);
  const year = useAtlas((s) => s.year);
  const playing = useAtlas((s) => s.playing);
  const layers = useAtlas((s) => s.layers);
  const basemap = useAtlas((s) => s.basemap);
  const storyOpen = useAtlas((s) => s.storyOpen);
  const setRiver = useAtlas((s) => s.setRiver);
  const setYear = useAtlas((s) => s.setYear);
  const setPlaying = useAtlas((s) => s.setPlaying);
  const toggleLayer = useAtlas((s) => s.toggleLayer);
  const setBasemap = useAtlas((s) => s.setBasemap);
  const setStoryOpen = useAtlas((s) => s.setStoryOpen);
  const reduce = usePrefersReducedMotion();
  const river = RIVER_BY_ID[riverId];
  const stats = useMemo(() => riverStats(river), [river]);
  const t = morphT(river, year);
  const [minYear, maxYear] = river.era;

  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let last = performance.now();
    const step = (now: number) => {
      const dt = now - last;
      last = now;
      const state = useAtlas.getState();
      const current = RIVER_BY_ID[state.riverId];
      const [lo, hi] = current.era;
      const span = hi - lo;
      const speed = span / (reduce ? 14000 : 9000);
      const next = state.year + (dt / 1000) * speed;
      if (next >= hi) {
        setYear(hi);
        setPlaying(false);
        return;
      }
      setYear(next);
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [playing, reduce, setYear, setPlaying]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      const i = RIVERS.findIndex((r) => r.id === riverId);
      if (e.key === "ArrowRight") {
        setRiver(RIVERS[(i + 1) % RIVERS.length].id);
      } else if (e.key === "ArrowLeft") {
        setRiver(RIVERS[(i - 1 + RIVERS.length) % RIVERS.length].id);
      } else if (e.key === " ") {
        e.preventDefault();
        setPlaying(!playing);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [riverId, playing, setRiver, setPlaying]);

  const layerButtons: { key: LayerKey; label: string; swatch: string }[] = [
    { key: "lost", label: "Lost bed", swatch: "bg-lost" },
    { key: "born", label: "New bed", swatch: "bg-born" },
    { key: "water", label: "Water", swatch: "bg-paper" },
  ];

  return (
    <div className="bg-bg text-fg flex h-dvh min-h-0 flex-col overflow-hidden md:flex-row">
      <aside className="border-border relative z-20 hidden w-80 shrink-0 flex-col overflow-hidden border-r md:flex">
        <Header />
        <div className="min-h-0 flex-1 overflow-y-auto">
          <RiverList riverId={riverId} onSelect={setRiver} />
          <Story riverId={riverId} stats={stats} t={t} year={year} />
        </div>
      </aside>

      <section className="relative min-h-0 min-w-0 flex-1">
        <RiverMap />

        <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-3 md:p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="pointer-events-auto md:hidden">
              <Header compact />
            </div>
            <div className="pointer-events-auto ml-auto flex flex-col items-end gap-2">
              <div className="bg-bg/92 shadow-[var(--shadow-border)] flex rounded-xl p-1">
                {BASEMAPS.map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => setBasemap(b.id)}
                    className={cn(
                      "flex h-11 items-center gap-1.5 rounded-lg px-2.5 text-xs font-medium transition-[background-color,color,opacity] duration-150",
                      basemap === b.id ? "bg-surface-2 text-fg" : "text-muted hover:text-fg",
                    )}
                    aria-pressed={basemap === b.id}
                  >
                    <BasemapIcon id={b.id} />
                    <span className="hidden sm:inline">{b.label}</span>
                  </button>
                ))}
              </div>
              <div className="bg-bg/92 shadow-[var(--shadow-border)] flex flex-col rounded-xl p-1">
                {layerButtons.map((b) => (
                  <button
                    key={b.key}
                    type="button"
                    onClick={() => toggleLayer(b.key)}
                    className={cn(
                      "flex h-11 items-center gap-2 rounded-lg px-2.5 text-xs font-medium transition-[background-color,color,opacity] duration-150",
                      layers[b.key] ? "text-fg" : "text-faint",
                    )}
                    aria-pressed={layers[b.key]}
                  >
                    <span className={cn("size-2 rounded-full", b.swatch, !layers[b.key] && "opacity-30")} />
                    {b.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="pointer-events-auto mx-auto w-full max-w-3xl">
            <TimeRail
              min={minYear}
              max={maxYear}
              year={year}
              eventYear={river.eventYear}
              eventLabel={river.eventLabel}
              playing={playing}
              t={t}
              onYear={setYear}
              onTogglePlay={() => setPlaying(!playing)}
            />
          </div>
        </div>
      </section>

      <div className="border-border bg-bg z-20 flex shrink-0 flex-col border-t md:hidden">
        <button
          type="button"
          className="flex h-11 items-center justify-between px-4 text-left"
          onClick={() => setStoryOpen(!storyOpen)}
          aria-expanded={storyOpen}
        >
          <span className="min-w-0">
            <span className="font-display block truncate text-base font-medium leading-tight">
              {river.name}
            </span>
            <span className="text-muted text-xs">{river.region}</span>
          </span>
          <ChevronDown
            className={cn(
              "text-muted size-4 shrink-0 transition-transform duration-200",
              storyOpen && "rotate-180",
            )}
          />
        </button>
        {storyOpen ? (
          <div className="max-h-[48dvh] overflow-y-auto px-4 pb-4">
            <RiverList riverId={riverId} onSelect={setRiver} compact />
            <Story riverId={riverId} stats={stats} t={t} year={year} />
          </div>
        ) : (
          <div className="flex gap-2 overflow-x-auto px-3 pb-3">
            {RIVERS.map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setRiver(r.id)}
                className={cn(
                  "h-9 shrink-0 rounded-full px-3 text-xs font-medium",
                  r.id === riverId ? "bg-paper text-ink" : "bg-surface-2 text-muted",
                )}
              >
                {r.name}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Header({ compact = false }: { compact?: boolean }) {
  return (
    <div className={cn("px-5 pt-5 pb-4", compact && "bg-bg/92 shadow-[var(--shadow-border)] rounded-xl px-3 py-2.5")}>
      <p className="text-faint font-mono text-xs tracking-widest uppercase">Atlas</p>
      <h1 className={cn("font-display mt-1 leading-none tracking-tight", compact ? "text-xl" : "text-3xl")}>
        OXBOW
      </h1>
      {!compact ? (
        <p className="text-muted mt-3 text-sm leading-relaxed text-pretty">
          Lost beds and new channels of India’s rivers.
        </p>
      ) : null}
    </div>
  );
}

function RiverList({
  riverId,
  onSelect,
  compact = false,
}: {
  riverId: RiverId;
  onSelect: (id: RiverId) => void;
  compact?: boolean;
}) {
  return (
    <nav className={cn(compact ? "py-2" : "px-3 pb-2")} aria-label="River reaches">
      {RIVERS.map((r) => {
        const active = r.id === riverId;
        return (
          <button
            key={r.id}
            type="button"
            onClick={() => onSelect(r.id)}
            className={cn(
              "flex w-full items-start gap-3 rounded-lg px-3 py-2.5 text-left transition-[background-color] duration-150",
              active ? "bg-surface-2" : "hover:bg-surface",
            )}
          >
            <span className={cn("mt-1.5 size-1.5 shrink-0 rounded-full", active ? "bg-paper" : "bg-faint")} />
            <span className="min-w-0 flex-1">
              <span className="flex items-baseline justify-between gap-2">
                <span className="font-medium">{r.name}</span>
                <span className="text-faint font-mono text-xs tabular-nums">{formatYear(r.eventYear)}</span>
              </span>
              <span className={cn("mt-0.5 block text-xs", KIND_TONE[r.kind])}>{KIND_LABEL[r.kind]}</span>
            </span>
          </button>
        );
      })}
    </nav>
  );
}

function Story({
  riverId,
  stats,
  t,
  year,
}: {
  riverId: RiverId;
  stats: ReturnType<typeof riverStats>;
  t: number;
  year: number;
}) {
  const river = RIVER_BY_ID[riverId];
  return (
    <div className="border-border space-y-4 border-t px-5 py-4">
      <div>
        <p className="text-faint font-mono text-xs tracking-widest uppercase">{river.region}</p>
        <h2 className="font-display mt-1 text-xl leading-tight text-balance">{river.lede}</h2>
      </div>
      <p className="text-muted text-sm leading-relaxed text-pretty">{river.essay}</p>
      <dl className="grid grid-cols-2 gap-3">
        <Stat label="Lost bed" value={formatKm(stats.lostKm)} tone="lost" />
        <Stat label="New bed" value={formatKm(stats.bornKm)} tone="born" />
        <Stat
          label="Sinuosity shift"
          value={`${stats.deltaKm > 0 ? "+" : ""}${formatKm(stats.deltaKm)}`}
        />
        <Stat label="In year" value={formatYear(year)} />
      </dl>
      {river.displaced ? (
        <p className="text-muted text-xs leading-relaxed">
          People displaced: <span className="text-fg">{river.displaced}</span>
        </p>
      ) : null}
      <p className="text-faint text-xs leading-relaxed">
        Traces are reconstructed from documented cutoffs and avulsions, simplified to the valley.
        Water position is interpolated across the event ({Math.round(t * 100)}% toward the new bed).
      </p>
    </div>
  );
}

function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: "lost" | "born";
}) {
  return (
    <div className="bg-surface rounded-lg px-3 py-2">
      <dt className="text-faint text-xs tracking-wide uppercase">{label}</dt>
      <dd
        className={cn(
          "mt-0.5 font-mono text-sm tabular-nums",
          tone === "lost" && "text-lost",
          tone === "born" && "text-born",
        )}
      >
        {value}
      </dd>
    </div>
  );
}

function TimeRail({
  min,
  max,
  year,
  eventYear,
  eventLabel,
  playing,
  t,
  onYear,
  onTogglePlay,
}: {
  min: number;
  max: number;
  year: number;
  eventYear: number;
  eventLabel: string;
  playing: boolean;
  t: number;
  onYear: (y: number) => void;
  onTogglePlay: () => void;
}) {
  const eventPct = ((eventYear - min) / (max - min)) * 100;
  return (
    <div className="bg-bg/92 shadow-[var(--shadow-border)] rounded-2xl p-3 md:p-4">
      <div className="mb-2 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-faint font-mono text-xs tracking-widest uppercase">Year</p>
          <p className="font-mono text-lg leading-none tabular-nums">{formatYear(year)}</p>
        </div>
        <p className="text-muted hidden max-w-[18rem] truncate text-right text-xs sm:block">{eventLabel}</p>
        <Button
          type="button"
          variant="subtle"
          size="icon"
          className="size-11 shrink-0"
          onClick={onTogglePlay}
          aria-label={playing ? "Pause channel change" : "Play channel change"}
        >
          {playing ? <Pause className="size-4" /> : <Play className="size-4 ml-0.5" />}
        </Button>
      </div>
      <div className="relative pt-3 pb-1">
        <span
          className="bg-paper/50 absolute top-0 h-2.5 w-px"
          style={{ left: `${eventPct}%` }}
          title={eventLabel}
        />
        <input
          type="range"
          min={min}
          max={max}
          step={1}
          value={Math.round(year)}
          onChange={(e) => onYear(Number(e.target.value))}
          className="time-range"
          aria-label="Year"
        />
      </div>
      <div className="text-faint mt-1 flex justify-between font-mono text-xs tabular-nums">
        <span>{formatYear(min)}</span>
        <span className="text-muted flex items-center gap-1.5">
          <Waves className="size-3" strokeWidth={1.75} />
          {t < 0.15 ? "on the old bed" : t > 0.85 ? "on the new bed" : "rewriting the bed"}
        </span>
        <span>{formatYear(max)}</span>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs">
        <LegendSwatch className="border-lost bg-lost/30 border-dashed" label="Abandoned" />
        <LegendSwatch className="border-born bg-born/30" label="New channel" />
        <LegendSwatch className="border-paper bg-paper/40" label="Water" />
        <span className="text-faint ml-auto">
          Imagery © Esri · CARTO · OSM
        </span>
      </div>
    </div>
  );
}

function LegendSwatch({ className, label }: { className: string; label: string }) {
  return (
    <span className="text-muted flex items-center gap-1.5">
      <span className={cn("h-2 w-5 rounded-sm border", className)} />
      {label}
    </span>
  );
}
