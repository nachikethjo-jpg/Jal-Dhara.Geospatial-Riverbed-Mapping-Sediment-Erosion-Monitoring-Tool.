import { useEffect, useRef } from "react";
import type { GeoJSONSource, Map as MapLibreMap } from "maplibre-gl";
import { buildScene, RIVER_BY_ID } from "@/lib/rivers";
import { MAP_PAINT, styleFor } from "@/lib/map-style";
import { useAtlas } from "@/store/atlas";

function makeHatch(): ImageData {
  const c = document.createElement("canvas");
  c.width = 16;
  c.height = 16;
  const g = c.getContext("2d");
  if (!g) return new ImageData(16, 16);
  g.clearRect(0, 0, 16, 16);
  g.strokeStyle = "rgba(196, 106, 74, 0.85)";
  g.lineWidth = 2;
  g.beginPath();
  g.moveTo(-2, 8);
  g.lineTo(8, -2);
  g.moveTo(0, 18);
  g.lineTo(18, 0);
  g.stroke();
  return g.getImageData(0, 0, 16, 16);
}

function addChannelLayers(map: MapLibreMap) {
  if (map.getSource("channels")) return;

  map.addSource("channels", {
    type: "geojson",
    data: { type: "FeatureCollection", features: [] },
  });

  map.addLayer({
    id: "scar-line",
    type: "line",
    source: "channels",
    filter: ["==", ["get", "kind"], "scar"],
    paint: {
      "line-color": MAP_PAINT.scar,
      "line-width": ["interpolate", ["linear"], ["zoom"], 5, 1.2, 10, 2.4, 14, 4],
      "line-dasharray": [1.2, 1.4],
      "line-opacity": 0.55,
    },
  });

  map.addLayer({
    id: "lost-fill",
    type: "fill",
    source: "channels",
    filter: ["==", ["get", "kind"], "lost-fill"],
    paint: {
      "fill-color": MAP_PAINT.lostFill,
      "fill-opacity": 0.85,
    },
  });

  if (!map.hasImage("lost-hatch")) {
    map.addImage("lost-hatch", makeHatch(), { pixelRatio: 2 });
  }

  map.addLayer({
    id: "lost-hatch",
    type: "fill",
    source: "channels",
    filter: ["==", ["get", "kind"], "lost-fill"],
    paint: {
      "fill-pattern": "lost-hatch",
      "fill-opacity": 0.45,
    },
  });

  map.addLayer({
    id: "loop-fill",
    type: "fill",
    source: "channels",
    filter: ["==", ["get", "kind"], "loop"],
    paint: {
      "fill-color": MAP_PAINT.loopFill,
      "fill-opacity": 0.9,
    },
  });

  map.addLayer({
    id: "born-fill",
    type: "fill",
    source: "channels",
    filter: ["==", ["get", "kind"], "born-fill"],
    paint: {
      "fill-color": MAP_PAINT.bornFill,
      "fill-opacity": 0.8,
    },
  });

  map.addLayer({
    id: "lost-line",
    type: "line",
    source: "channels",
    filter: ["==", ["get", "kind"], "lost"],
    layout: { "line-cap": "round", "line-join": "round" },
    paint: {
      "line-color": MAP_PAINT.lost,
      "line-width": ["interpolate", ["linear"], ["zoom"], 5, 1.6, 8, 2.8, 12, 5, 15, 8],
      "line-dasharray": [1.6, 1.1],
      "line-opacity": 0.95,
    },
  });

  map.addLayer({
    id: "born-line",
    type: "line",
    source: "channels",
    filter: ["==", ["get", "kind"], "born"],
    layout: { "line-cap": "round", "line-join": "round" },
    paint: {
      "line-color": MAP_PAINT.born,
      "line-width": ["interpolate", ["linear"], ["zoom"], 5, 1.8, 8, 3.2, 12, 5.5, 15, 9],
      "line-opacity": 0.95,
    },
  });

  map.addLayer({
    id: "water-glow",
    type: "line",
    source: "channels",
    filter: ["==", ["get", "kind"], "water"],
    layout: { "line-cap": "round", "line-join": "round" },
    paint: {
      "line-color": MAP_PAINT.waterGlow,
      "line-width": ["interpolate", ["linear"], ["zoom"], 5, 4, 8, 8, 12, 14, 15, 22],
      "line-blur": ["interpolate", ["linear"], ["zoom"], 5, 2, 12, 6],
      "line-opacity": 0.55,
    },
  });

  map.addLayer({
    id: "water-core",
    type: "line",
    source: "channels",
    filter: ["==", ["get", "kind"], "water"],
    layout: { "line-cap": "round", "line-join": "round" },
    paint: {
      "line-color": MAP_PAINT.water,
      "line-width": ["interpolate", ["linear"], ["zoom"], 5, 1.4, 8, 2.4, 12, 4, 15, 6.5],
      "line-opacity": 0.95,
    },
  });
}

function setLayerVis(map: MapLibreMap, ids: string[], visible: boolean) {
  for (const id of ids) {
    if (map.getLayer(id)) {
      map.setLayoutProperty(id, "visibility", visible ? "visible" : "none");
    }
  }
}

export function RiverMap() {
  const hostRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<MapLibreMap | null>(null);
  const readyRef = useRef(false);
  const riverId = useAtlas((s) => s.riverId);
  const year = useAtlas((s) => s.year);
  const layers = useAtlas((s) => s.layers);
  const basemap = useAtlas((s) => s.basemap);
  const stateRef = useRef({ riverId, year, layers, basemap });
  stateRef.current = { riverId, year, layers, basemap };

  const flownRef = useRef<string | null>(null);

  useEffect(() => {
    if (!hostRef.current) return;
    let cancelled = false;
    let map: MapLibreMap | undefined;
    let ro: ResizeObserver | undefined;

    const apply = (m: MapLibreMap) => {
      if (!m.isStyleLoaded()) return;
      addChannelLayers(m);
      const st = stateRef.current;
      const river = RIVER_BY_ID[st.riverId];
      const src = m.getSource("channels") as GeoJSONSource | undefined;
      src?.setData(buildScene(river, st.year));
      setLayerVis(m, ["lost-fill", "lost-hatch", "lost-line", "loop-fill", "scar-line"], st.layers.lost);
      setLayerVis(m, ["born-fill", "born-line"], st.layers.born);
      setLayerVis(m, ["water-glow", "water-core"], st.layers.water);
    };

    void (async () => {
      const maplibregl = await import("maplibre-gl");
      const host = hostRef.current;
      if (cancelled || !host) return;
      maplibregl.setWorkerUrl("/maplibre/maplibre-gl-worker.mjs");
      const river = RIVER_BY_ID[stateRef.current.riverId];
      map = new maplibregl.Map({
        container: host,
        style: styleFor(stateRef.current.basemap),
        center: river.view.center,
        zoom: river.view.zoom,
        pitch: river.view.pitch,
        bearing: river.view.bearing,
        attributionControl: false,
        maxPitch: 62,
        fadeDuration: 0,
      });
      map.on("load", () => {
        if (!map) return;
        apply(map);
        const current = RIVER_BY_ID[stateRef.current.riverId];
        map.jumpTo({
          center: current.view.center,
          zoom: current.view.zoom,
          pitch: current.view.pitch,
          bearing: current.view.bearing,
        });
        flownRef.current = stateRef.current.riverId;
        readyRef.current = true;
      });
      map.on("style.load", () => {
        if (!map) return;
        apply(map);
      });
      mapRef.current = map;
      ro = new ResizeObserver(() => map?.resize());
      ro.observe(host);
    })();

    return () => {
      cancelled = true;
      readyRef.current = false;
      ro?.disconnect();
      map?.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !readyRef.current) return;
    if (flownRef.current === riverId) return;
    flownRef.current = riverId;
    const river = RIVER_BY_ID[riverId];
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    map.flyTo({
      center: river.view.center,
      zoom: river.view.zoom,
      pitch: river.view.pitch,
      bearing: river.view.bearing,
      duration: reduce ? 0 : 2200,
      essential: true,
    });
  }, [riverId]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !readyRef.current) return;
    if (map.getStyle()?.name === basemap) return;
    map.setStyle(styleFor(basemap));
  }, [basemap]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !readyRef.current || !map.isStyleLoaded()) return;
    const river = RIVER_BY_ID[riverId];
    const src = map.getSource("channels") as GeoJSONSource | undefined;
    src?.setData(buildScene(river, year));
    setLayerVis(map, ["lost-fill", "lost-hatch", "lost-line", "loop-fill", "scar-line"], layers.lost);
    setLayerVis(map, ["born-fill", "born-line"], layers.born);
    setLayerVis(map, ["water-glow", "water-core"], layers.water);
  }, [riverId, year, layers]);

  return (
    <div className="relative h-full min-h-0 w-full">
      <div ref={hostRef} className="bg-bg absolute inset-0" />
    </div>
  );
}
