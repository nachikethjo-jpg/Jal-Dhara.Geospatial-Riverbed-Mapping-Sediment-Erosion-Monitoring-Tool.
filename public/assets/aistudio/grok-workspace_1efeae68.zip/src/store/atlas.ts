import { create } from "zustand";
import { RIVERS, type RiverId } from "@/lib/rivers";
import type { BasemapId } from "@/lib/map-style";

export type LayerKey = "lost" | "born" | "water";

type AtlasState = {
  riverId: RiverId;
  year: number;
  playing: boolean;
  layers: Record<LayerKey, boolean>;
  basemap: BasemapId;
  storyOpen: boolean;
  setRiver: (id: RiverId) => void;
  setYear: (year: number) => void;
  setPlaying: (playing: boolean) => void;
  toggleLayer: (key: LayerKey) => void;
  setBasemap: (id: BasemapId) => void;
  setStoryOpen: (open: boolean) => void;
};

const first = RIVERS[0];

export const useAtlas = create<AtlasState>((set, get) => ({
  riverId: first.id,
  year: first.eventYear,
  playing: false,
  layers: { lost: true, born: true, water: true },
  basemap: "satellite",
  storyOpen: false,
  setRiver: (id) => {
    const river = RIVERS.find((r) => r.id === id) ?? first;
    set({ riverId: river.id, year: river.eventYear, playing: false });
  },
  setYear: (year) => set({ year }),
  setPlaying: (playing) => set({ playing }),
  toggleLayer: (key) => {
    const layers = get().layers;
    set({ layers: { ...layers, [key]: !layers[key] } });
  },
  setBasemap: (id) => set({ basemap: id }),
  setStoryOpen: (open) => set({ storyOpen: open }),
}));
