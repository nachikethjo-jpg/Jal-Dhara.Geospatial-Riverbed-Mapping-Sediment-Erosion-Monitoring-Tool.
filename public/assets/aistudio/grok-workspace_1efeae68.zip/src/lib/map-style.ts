import type { StyleSpecification } from "maplibre-gl";

export type BasemapId = "satellite" | "terrain" | "ink";

export const MAP_PAINT = {
  lost: "#c46a4a",
  lostFill: "rgba(196, 106, 74, 0.30)",
  loopFill: "rgba(196, 106, 74, 0.22)",
  born: "#4aa89a",
  bornFill: "rgba(74, 168, 154, 0.28)",
  water: "#e7f6f1",
  waterGlow: "#3d9b8f",
  scar: "rgba(196, 106, 74, 0.45)",
  ink: "#0b100e",
  paper: "#e8e2d6",
};

const esriImagery =
  "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
const esriTopo =
  "https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}";
const cartoInk = "https://basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}@2x.png";

function rasterStyle(
  id: string,
  tiles: string[],
  attribution: string,
  bg: string,
): StyleSpecification {
  return {
    version: 8,
    name: id,
    sources: {
      basemap: {
        type: "raster",
        tiles,
        tileSize: 256,
        attribution,
        maxzoom: 19,
      },
    },
    layers: [
      { id: "background", type: "background", paint: { "background-color": bg } },
      { id: "basemap", type: "raster", source: "basemap" },
    ],
  };
}

export function styleFor(id: BasemapId): StyleSpecification {
  if (id === "satellite") {
    return rasterStyle(
      "satellite",
      [esriImagery],
      "Imagery © Esri",
      MAP_PAINT.ink,
    );
  }
  if (id === "terrain") {
    return rasterStyle(
      "terrain",
      [esriTopo],
      "Topo © Esri",
      "#d6d2c4",
    );
  }
  return rasterStyle(
    "ink",
    [cartoInk],
    "© CARTO © OSM",
    MAP_PAINT.ink,
  );
}

export const BASEMAPS: { id: BasemapId; label: string }[] = [
  { id: "satellite", label: "Satellite" },
  { id: "terrain", label: "Terrain" },
  { id: "ink", label: "Ink" },
];
